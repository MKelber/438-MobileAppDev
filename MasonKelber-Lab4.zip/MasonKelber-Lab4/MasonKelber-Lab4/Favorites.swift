//
//  Favorites.swift
//  MasonKelber-Lab4
//
//  Created by Snow Hao on 11/10/20.
//  Copyright © 2020 MasonKelber. All rights reserved.
//

import Foundation
import UIKit

class Favorites: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!
    
}
