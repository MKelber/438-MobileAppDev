//
//  CollectionCell.swift
//  MasonKelber-Lab4
//
//  Created by Snow Hao on 11/9/20.
//  Copyright © 2020 MasonKelber. All rights reserved.
//

import Foundation
import UIKit

class CollectionCell:UICollectionViewCell{
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
}
